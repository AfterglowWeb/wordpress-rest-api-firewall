<?php namespace cmk\RestApiFirewall\Models;

defined( 'ABSPATH' ) || exit;

use cmk\RestApiFirewall\Controllers\ModelContext;
use cmk\RestApiFirewallPro\Controllers\ModelsPropertiesControllerPro;
use WP_User;

class PostModel {

	public function __invoke( array $post, ModelContext $context ): array {

		$post = $this->remove_disabled_properties( $post, $context );
		$post = $this->apply_filters( $post, $context );

		return apply_filters(
			'rest_firewall_model_post',
			$post,
			$context
		);
	}

	private function remove_disabled_properties( array $post, ModelContext $context ): array {

		foreach ( array_keys( $post ) as $property_key ) {
			if ( $context->is_disabled( $property_key ) ) {
				unset( $post[ $property_key ] );
			}
		}

		return $post;
	}

	private function apply_filters( array $post, ModelContext $context ): array {

		if ( class_exists( '\cmk\RestApiFirewallPro\Controllers\ModelsPropertiesControllerPro' ) ) {
			if ( isset( $post['link'] ) && $context->should_relative_url( 'link' ) ) {
				$post['link'] = ModelsPropertiesControllerPro::relative_url( $post['link'] );
			}

			if ( isset( $post['guid'] ) && $context->should_relative_url( 'guid' ) ) {
				$post['guid'] = is_array( $post['guid'] )
					? ModelsPropertiesControllerPro::relative_url( $post['guid']['rendered'] ?? '' )
					: ModelsPropertiesControllerPro::relative_url( $post['guid'] );
			}

			if ( $context->with_acf && isset( $post['id'] ) ) {
				$acf = ModelsPropertiesControllerPro::embed_acf_fields( $post['id'] );
				if ( $acf ) {
					$post['acf'] = $acf;
				} elseif ( isset( $post['acf'] ) ) {
					unset( $post['acf'] );
				}
			}
		}

		foreach ( array( 'title', 'excerpt', 'content', 'guid' ) as $rendered_prop ) {
			if ( isset( $post[ $rendered_prop ] ) && $context->should_render( $rendered_prop ) ) {
				if ( is_array( $post[ $rendered_prop ] ) && isset( $post[ $rendered_prop ]['rendered'] ) ) {
					$post[ $rendered_prop ] = $post[ $rendered_prop ]['rendered'];
				}
			}
		}

		if ( isset( $post['featured_media'] ) && $context->should_embed( 'featured_media' ) ) {
			$attachment_model       = new AttachmentModel();
			$post['featured_media'] = $attachment_model( (int) $post['featured_media'], $context );
		}

		if ( isset( $post['author'] ) && $context->should_embed( 'author' ) ) {
			$user = get_userdata( $post['author'] );
			if ( $user instanceof WP_User ) {
				$author_model   = new AuthorModel();
				$post['author'] = $author_model( $user, $context );
			}
		}

		if ( $context->should_embed( 'terms' ) ) {
			$post['terms'] = $this->embed_terms( $post, $context );
		}

		if ( $context->remove_links_prop && isset( $post['_links'] ) ) {
			unset( $post['_links'] );
		}

		if ( $context->remove_empty_props ) {
			$post = array_filter( $post, fn( $value ) => ! empty( $value ) || 0 === $value || false === $value );
		}

		return $post;
	}

	private function embed_terms( array $post, ModelContext $context ): array {

		if ( empty( $post['id'] ) ) {
			return array();
		}

		$post_id    = (int) $post['id'];
		$taxonomies = get_object_taxonomies( get_post_type( $post_id ), 'names' );
		$terms_data = array();
		$term_model = new TermModel();

		foreach ( $taxonomies as $taxonomy ) {
			$terms = wp_get_post_terms( $post_id, $taxonomy );

			if ( is_wp_error( $terms ) || empty( $terms ) ) {
				continue;
			}

			$terms_data[ $taxonomy ] = array_map(
				fn( $term ) => $term_model( (array) $term, $context ),
				$terms
			);
		}

		return $terms_data;
	}
}
