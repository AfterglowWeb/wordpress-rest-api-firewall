<?php namespace cmk\RestApiFirewall\Models;

defined( 'ABSPATH' ) || exit;

use cmk\RestApiFirewall\Controllers\ModelContext;
use cmk\RestApiFirewallPro\Controllers\ModelsPropertiesControllerPro;

class MenuItemModel {

	public function __invoke( array $menu_item, ModelContext $context ): array {

		$menu_item = $this->remove_disabled_properties( $menu_item, $context );
		$menu_item = $this->apply_filters( $menu_item, $context );

		return apply_filters(
			'rest_firewall_model_menu_item',
			$menu_item,
			$context
		);
	}

	protected function remove_disabled_properties( array $menu_item, ModelContext $context ): array {

		foreach ( array_keys( $menu_item ) as $property_key ) {
			if ( $context->is_disabled( $property_key ) ) {
				unset( $menu_item[ $property_key ] );
			}
		}

		return $menu_item;
	}

	protected function apply_filters( array $menu_item, ModelContext $context ): array {

		if ( class_exists( '\cmk\RestApiFirewallPro\Controllers\ModelsPropertiesControllerPro' ) && isset( $menu_item['url'] ) && $context->should_relative_url( 'url' ) ) {
				$menu_item['url'] = ModelsPropertiesControllerPro::relative_url( $menu_item['url'] );
		}

		if ( isset( $menu_item['title'] ) && $context->should_render( 'title' ) ) {
			if ( is_array( $menu_item['title'] ) && isset( $menu_item['title']['rendered'] ) ) {
				$menu_item['title'] = $menu_item['title']['rendered'];
			}
		}

		if ( class_exists( '\cmk\RestApiFirewallPro\Controllers\ModelsPropertiesControllerPro' ) && $context->with_acf && isset( $menu_item['id'] ) ) {

			$acf = ModelsPropertiesControllerPro::embed_acf_fields( $menu_item['id'] );
			if ( $acf ) {
				$menu_item['acf'] = $acf;
			} elseif ( isset( $menu_item['acf'] ) ) {
				unset( $menu_item['acf'] );
			}
		}

		if ( $context->remove_links_prop && isset( $menu_item['_links'] ) ) {
			unset( $menu_item['_links'] );
		}

		return $menu_item;
	}
}
